Default-wps-pin
===============

Vodafone EasyBox default wps pin algorithm
