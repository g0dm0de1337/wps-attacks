wpsdb_api
=========

Connect to wpsdb.site40.net api to retrieve WPS PIN's



USE:

./pwsdb.sh AABBCC

* AABBCC parameter from a BSSID like AA:BB:CC:DD:EE:FF
